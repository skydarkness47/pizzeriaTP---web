miApp.service('factoryRutas', function () {
 var objeto ={};
   objeto.nombre = "factory de rutas";
   objeto.ApiUrl = "http://prog4jaguirre.esy.es/ws1/";
 


   return objeto;
  })//cierro factory
