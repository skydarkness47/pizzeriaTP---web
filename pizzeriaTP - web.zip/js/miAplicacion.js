var miApp = angular.module(
	"AngularABM",
	[
	"ui.router",
	"angularFileUpload",
	'satellizer',
    'ui.grid',
    'ngMap',
    'ui.grid.pagination',
    'ui.grid.resizeColumns',
    'ui.grid.selection',
    'ui.grid.exporter',
    'ui.grid.edit'
	])




